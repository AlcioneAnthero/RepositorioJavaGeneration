package PacoteJava;

public class ClasseGeneration {
	public static void main(String args[])
	{
		System.out.println("Ol� Alcione bem vinda ao Java");
	}
	
}
